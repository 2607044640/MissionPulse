// Fill out your copyright notice in the Description page of Project Settings.


#include "SaveStringByJson.h"
#include "MyRewardProject/MyRewardProject.h"


bool USaveStringByJson::SaveData(FString StringIP)
{
	TSharedPtr<FJsonObject> MainJsonObject(new FJsonObject);


	//MainData
	TArray<TSharedPtr<FJsonValue>> OtherJsonValues;
	TSharedPtr<FJsonObject> OtherJsonObject(new FJsonObject);

	OtherJsonObject->SetStringField(TEXT("StringIP"), StringIP);

	OtherJsonValues.Add(MakeShareable(new FJsonValueObject(OtherJsonObject)));

	MainJsonObject->SetArrayField(TEXT("MainData"), OtherJsonValues);

	// Serialize JSON object to a string
	FString JsonStr;
	TSharedRef<TJsonWriter<>> JsonWriter = TJsonWriterFactory<>::Create(&JsonStr);

	if (FJsonSerializer::Serialize(MainJsonObject.ToSharedRef(), JsonWriter))
	{
		// Save the JSON string to a file
		FString FilePath =  TEXT("TestSaved/IPSavedFolder/") + StringSaveDataFileName;

		if (FFileHelper::SaveStringToFile(JsonStr, *FilePath))
		{
			// FString TempStr1 = FString::Printf(TEXT("File saved successfully at %s"), *FilePath);
			// if (GEngine) GEngine->AddOnScreenDebugMessage(-1, 2.f, FColor::Red, TempStr1, true);
			// UE_LOG(LogTemp, Error, TEXT("%s"), *TempStr1);
			return true;
		}
	}
	return false;
}

bool USaveStringByJson::LoadData(FString& StringIP)
{
	FString FilePath =TEXT("TestSaved/IPSavedFolder/") + StringSaveDataFileName;


	FString Result;
	if (FFileHelper::LoadFileToString(Result, *FilePath))
	{
		TSharedRef<TJsonReader<>> JsonReader = TJsonReaderFactory<>::Create(Result);
		TSharedPtr<FJsonObject> JsonObject;

		if (FJsonSerializer::Deserialize(JsonReader, JsonObject))
		{
			// Load task data
			const TArray<TSharedPtr<FJsonValue>>* JsonValues;

			if (JsonObject->TryGetArrayField(TEXT("MainData"), JsonValues))
			{
				for (const TSharedPtr<FJsonValue>& JsonValue : *JsonValues)
				{
					if (TSharedPtr<FJsonObject> OtherObject = JsonValue->AsObject())
					{
						StringIP = OtherObject->GetStringField(TEXT("StringIP"));
					}
				}
			}
			return true;
		}
	}
	return false;
}
