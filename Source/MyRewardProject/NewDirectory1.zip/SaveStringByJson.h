// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Subsystems/GameInstanceSubsystem.h"
#include "SaveStringByJson.generated.h"

/**
 * 
 */
UCLASS()
class MYREWARDPROJECT_API USaveStringByJson : public UGameInstanceSubsystem
{
public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=JFSetting)
	FString StringSaveDataFileName=TEXT("MySavedData");

	UFUNCTION(BlueprintCallable, Category = "SaveData")
	bool SaveData(FString StringIP);

	UFUNCTION(BlueprintCallable, Category = "LoadData")
	bool LoadData(FString& StringIP);

	GENERATED_BODY()
};
