// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

inline const FString SaveDataFileName=TEXT("MySavedData");
inline FString InitalName_AllTasks = TEXT("AllTasks");
