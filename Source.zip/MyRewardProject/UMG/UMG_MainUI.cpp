// Fill out your copyright notice in the Description page of Project Settings.


#include "UMG_MainUI.h"

void UUMG_MainUI::NativeConstruct()
{
	Super::NativeConstruct();
}