// Copyright Epic Games, Inc. All Rights Reserved.

#include "MyRewardProject.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, MyRewardProject, "MyRewardProject" );
